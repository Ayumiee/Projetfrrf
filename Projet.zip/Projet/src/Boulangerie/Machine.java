package Boulangerie;


public class Machine {
	private Inventaire inventaire;
	
	public Machine() {
		this.inventaire= new Inventaire();
		
	}
	
	public void achat(int produit,int argent) {
		inventaire.getbaguette();
	}
	
	
	public static void main(String[] args) {
		Machine machine = new Machine();
		machine.achat(1,2);
	}
}



